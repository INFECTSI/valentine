(() => {
  if (window.__valentineImportInjected) return;
  window.__valentineImportInjected = true;

  const SOURCE = /(^|\.)leboncoin\.fr$/i.test(location.hostname) ? 'Leboncoin' : 'SeLoger';
  const API = 'http://127.0.0.1:8766';

  const button = document.createElement('button');
  button.type = 'button';
  button.textContent = `Importer cette page (${SOURCE})`;
  Object.assign(button.style, {
    position: 'fixed',
    right: '18px',
    bottom: '18px',
    zIndex: '2147483647',
    padding: '12px 16px',
    border: '0',
    borderRadius: '12px',
    background: '#d95d39',
    color: '#fff',
    fontFamily: 'system-ui, sans-serif',
    fontWeight: '800',
    fontSize: '14px',
    boxShadow: '0 10px 30px rgba(0,0,0,.25)',
    cursor: 'pointer',
  });

  button.addEventListener('click', async () => {
    button.disabled = true;
    button.textContent = 'Import en cours…';
    try {
      const response = await fetch(`${API}/api/import`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: location.href,
          html: document.documentElement.outerHTML,
          source: SOURCE,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
      button.textContent = data.count
        ? `${data.count} annonce${data.count > 1 ? 's' : ''} ${SOURCE} importée${data.count > 1 ? 's' : ''}`
        : 'Aucune annonce détectée';
    } catch (error) {
      button.textContent = 'Erreur — API 8766 lancée ?';
      console.error('[Valentine]', error);
    } finally {
      setTimeout(() => {
        button.disabled = false;
        button.textContent = `Importer cette page (${SOURCE})`;
      }, 6000);
    }
  });

  document.documentElement.appendChild(button);
})();
