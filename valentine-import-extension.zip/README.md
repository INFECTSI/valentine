# Extension Valentine — import SeLoger & Leboncoin

SeLoger et Leboncoin sont protégés par DataDome : le serveur de Valentine ne peut pas lire
leurs pages. Cette extension fait la même chose qu'une **WebView visible** : elle lit la page
**dans ton navigateur**, après que tu as passé le contrôle, et l'envoie à l'API locale.

## Installation (Chrome / Edge)

1. Ouvre `chrome://extensions` (ou `edge://extensions`).
2. Active **Mode développeur**.
3. Clique **Charger l'extension non empaquetée**.
4. Choisis le dossier `se-loger-extension`.
5. Ouvre SeLoger ou Leboncoin dans un onglet, passe le contrôle DataDome si nécessaire.
6. Un bouton **« Importer cette page (SeLoger) »** ou **« … (Leboncoin) »** apparaît en bas à droite.
7. Clique dessus. Les annonces sont ajoutées à la source correspondante dans Valentine.

## Utilisation

- L'API doit tourner sur `http://127.0.0.1:8766`.
- L'extension lit le DOM de la page ouverte (pas de contournement de CAPTCHA).
- Elle fonctionne sur les pages de résultats et les pages de détail.
- Les annonces importées restent en mémoire du serveur tant qu'il tourne.
- Dans Valentine : bouton **« Importer SeLoger / Leboncoin »** en haut à droite, ou onglet
  pointillé **« ＋ SeLoger · importer »** sous les résultats.
- Après un import, reviens sur Valentine et relance la recherche : les annonces apparaissent
  avec les autres sources, et le badge de source indique SeLoger ou Leboncoin.

## Alternative sans extension

Ouvre `import.html`, choisis la source, colle le HTML de la page et clique sur « Importer ».
Pour récupérer le HTML : `F12` → Elements → clic droit sur `<html>` → Copy → Copy outerHTML.
